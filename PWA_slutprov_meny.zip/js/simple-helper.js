Helper.show = function (tag) {
    document.getElementById(tag).style.display="block";
}

Helper.hide = function (tag) {
    document.getElementById(tag).style.display="none";
}
